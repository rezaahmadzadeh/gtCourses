Computation done with the 11 moth old URDF model. This model was not valid as Dave forgot to push the new version on github.
