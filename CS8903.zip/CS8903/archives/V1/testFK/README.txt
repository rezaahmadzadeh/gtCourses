Computation done with the updated URDF model. There still is a shift problem.
