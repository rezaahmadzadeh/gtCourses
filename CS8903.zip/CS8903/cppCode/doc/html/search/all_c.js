var searchData=
[
  ['q_5ft',['q_t',['../types_8h.html#ac93021229dd8838987c783b2a6f13b92',1,'types.h']]],
  ['qnorm',['qNorm',['../misc_8h.html#affaddad50a1a843ccde93ea5424ce575',1,'misc.cpp']]]
];
