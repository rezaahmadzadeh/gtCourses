var searchData=
[
  ['r2d',['R2D',['../macros_8h.html#a39c663074332446065723e9be9350139',1,'macros.h']]],
  ['raw_5fdata',['RAW_DATA',['../macros_8h.html#a7140d943b6f40ad3c4bdab5a2073c2f6',1,'macros.h']]],
  ['root_5fdir',['ROOT_DIR',['../macros_8h.html#a62b075ec29b7b301c68f539d8aafd029',1,'macros.h']]]
];
