var searchData=
[
  ['solutionsstorage',['solutionsStorage',['../types_8h.html#a72cfbd4e488a6e150456db7a27c5d92d',1,'types.h']]]
];
