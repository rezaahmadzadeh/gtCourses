var searchData=
[
  ['numset',['NUMSET',['../macros_8h.html#aa6f335a67284eb1426a7b5683a9fedb1',1,'macros.h']]]
];
