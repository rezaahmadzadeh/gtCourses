var searchData=
[
  ['vertex',['Vertex',['../GraphSearch_8h.html#ac4ad596873793f04ffb3f20a24d93e0f',1,'GraphSearch.h']]]
];
