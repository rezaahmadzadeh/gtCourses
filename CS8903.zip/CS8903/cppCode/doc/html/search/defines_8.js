var searchData=
[
  ['source_5fdata_5fdir',['SOURCE_DATA_DIR',['../macros_8h.html#a8534b8ee4bdb66bcfee47dd9658a6d29',1,'macros.h']]],
  ['source_5fdata_5fpath',['SOURCE_DATA_PATH',['../macros_8h.html#a81ed4adb39bb4db988fab20d8595b055',1,'macros.h']]]
];
