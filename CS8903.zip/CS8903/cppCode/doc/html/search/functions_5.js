var searchData=
[
  ['qnorm',['qNorm',['../misc_8h.html#affaddad50a1a843ccde93ea5424ce575',1,'misc.cpp']]]
];
