var searchData=
[
  ['mymax',['myMax',['../misc_8h.html#a8a44b1961daf53a8bb6ef2e16a980361',1,'misc.cpp']]],
  ['mymin',['myMin',['../misc_8h.html#a531c23bbcd324ea8ccf45f78fe3299ec',1,'misc.cpp']]]
];
